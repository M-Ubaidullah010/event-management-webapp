let myEvents = [
    { name: "Music Fest", date: "2024-12-20", desc: "A great concert." },
    { name: "Old Expo", date: "2023-01-05", desc: "Last year's expo." }
];
const listDiv = document.getElementById('eventList');
const form = document.getElementById('eventForm');
const searchBox = document.getElementById('search');
function showEvents(filterText = "") {
    listDiv.innerHTML = "";
    myEvents.sort(function(a, b) {
        return new Date(a.date) - new Date(b.date);
    });
    let today = new Date().toISOString().split('T');
    for (let i = 0; i < myEvents.length; i++) {
        let event = myEvents[i];
        if (event.name.toLowerCase().includes(filterText.toLowerCase()) || event.date.includes(filterText)) {
            let card = document.createElement('div');
            card.className = "event-card";        
            if (event.date < today) {
                card.classList.add('past');
            }
            card.innerHTML = "<h4>" + event.name + "</h4>" +
                             "<p>Date: " + event.date + "</p>" +
                             "<p>" + event.desc + "</p>" +
                             "<button class='del-btn' onclick='removeEvent(" + i + ")'>Delete</button>";
            
            listDiv.appendChild(card);
        }
    }
}
form.onsubmit = function(e) {
    e.preventDefault();
    let nameVal = document.getElementById('name').value;
    let dateVal = document.getElementById('date').value;
    let descVal = document.getElementById('desc').value;
    let msg = document.getElementById('msg');

    if (nameVal === "" || dateVal === "" || descVal === "") {
        msg.style.display = "block";
        return;
    }
    msg.style.display = "none";
    myEvents.push({ name: nameVal, date: dateVal, desc: descVal });
    form.reset();
    showEvents();
};
function removeEvent(index) {
    myEvents.splice(index, 1);
    showEvents();
}
searchBox.oninput = function() {
    showEvents(searchBox.value);
};
showEvents();